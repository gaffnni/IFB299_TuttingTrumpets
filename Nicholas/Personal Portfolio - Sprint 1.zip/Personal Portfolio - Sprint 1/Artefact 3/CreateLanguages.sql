Set @LanguageName = 'Italian';

Insert Into languages(Name)
Select @LanguageName;