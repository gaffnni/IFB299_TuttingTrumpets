Set @InstrumentName = 'Clarinet';

Insert Into tt.instruments(Name)
Select @InstrumentName