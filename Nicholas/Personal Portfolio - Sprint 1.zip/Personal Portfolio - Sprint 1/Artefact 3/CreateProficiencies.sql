Set @ProficiencyName = 'Awful';

#Create Proficiencies
Insert into proficiency(Name)
Select @ProficiencyName