Set @DesiredUserName = 'Senator';

Select Id
From accounts
Where Username = @DesiredUserName;